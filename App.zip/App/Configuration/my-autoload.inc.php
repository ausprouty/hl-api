<?php

// autoload.php

spl_autoload_register(function ($className) {
    // Get the relative class name and replace namespace separators with directory separators
    $className = str_replace('\\', '/', $className);
    // Build the full path to the class file
    $file = AUTOLOADER_ROOT . $className . '.php';

    // If the file exists, require it
    if (file_exists($file)) {
        require $file;
    }
    else{
        writeLogDebug('autoload-17', $className);
        echo ('not found');

    }
});
