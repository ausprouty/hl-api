<?php
define('WORDPRESS_HL_API_KEY', 'd4e56a8f93b64527a7e14e4c2f7b9d2b');
define('DB_HOST','localhost');
define('DB_DATABASE','hl_api');
define('DB_USERNAME','hl_api');
define('DB_PASSWORD','test2024!');
define('DB_PORT','3306');
define('WEBPORT','90');


define('DB_CHARSET','utf8_general_ci');
define('DB_COLLATION','utf8_general_ci');
define('PREFIX','');
define('FILE_ROOT', 'c:/ampp/htdocs');
define ('WEB_ROOT',  '/hl-api/');


define ('AUTOLOADER_ROOT', FILE_ROOT . WEB_ROOT );
define ('ROOT',  '/hl-api/');
define ('ROOT_IMPORT_DATA', 'c:/ampp/htdocs/hl-api/imports/data/');
define ('ROOT_LIBRARIES', FILE_ROOT . WEB_ROOT  .'App/Libraries');
define ('ROOT_LOG', 'c:/ampp/htdocs/hl-api/App/Logs/');
define ('ROOT_RESOURCES', 'c:/ampp/htdocs/hl-api/Resources/');
define ('WEBADDRESS_RESOURCES', 'http://localhost/hl-api/Resources/');
define ('ROOT_STYLES', 'c:/ampp/htdocs/hl-api/App/Styles/');
define ('ROOT_FONTS', 'c:/ampp/htdocs/hl-api/App/Fonts/');
define ('ROOT_TEMPLATES', 'c:/ampp/htdocs/hl-api/App/Templates/');
define ('ROOT_TRANSLATIONS', 'c:/ampp/htdocs/hl-api/Resources/translations/');
define ('ROOT_VENDOR', 'c:/ampp/htdocs/hl-api/Vendor/');
define ('LOG_MODE',  'write_log');
define('JVIDEO_SOURCE', 'src="https://api.arclight.org/videoPlayerUrl?refId=');
define('ACCEPTABLE_IP', '*');
define('DBT_KEY', '3d116e49d7d98c6e20bf0f4a9c88e4cc');
define('BIBLE_BRAIN_KEY', '1462b719-42d8-0874-7c50-905063472458');
define('YOUR_AZURE_SUBSCRIPTION_KEY', '0b63f7a5a13e4f20ac59838ccd6d0bf1');