<?php

header('Content-Type: application/json');

$data = 'how are all of you doing?';
// Output the JSON data
echo json_encode($data);