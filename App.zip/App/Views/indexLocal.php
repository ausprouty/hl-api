<?php
echo"fred"; 
echo "

<h1>API calls</h1>
<p><a href= '/hl-api/rcd/spirit/titles'>Spirit Titles</a></p>
<p><a href= '/hl-api/rcd/tracts/view'>Tracts to View</a></p>


<h1> Tests for HL-API</h1>
<p><a href= '/hl-api/test/spirit/titles'>Spirit Titles</a></p>
<p><a href= '/hl-api/test/tracts/view'>Tracts to View</a></p>
<p><a href= '/hl-api/test/tracts/monolingual'>Tracts Monolingual</a></p>
<p><a href= '/hl-api/test/tracts/bilingual/english'>Tracts Bi-lingual English</a></p>


";