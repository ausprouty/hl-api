<?php
return 'This means you did not come though the router';